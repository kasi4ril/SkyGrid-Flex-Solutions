#!/usr/bin/env bash
# ==============================================================================
# Growatt PAYG Enterprise - Unified Process Orchestrator (start_all.sh)
# Boots Infrastructure, Core Go Backend, Background Workers & Intelligence Engine
# ==============================================================================

set -eo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$SCRIPT_DIR"

if [ -d "$ROOT_DIR/growatt-payg-enterprise" ]; then
    ROOT_DIR="$ROOT_DIR/growatt-payg-enterprise"
fi

LOG_DIR="$ROOT_DIR/logs"
mkdir -p "$LOG_DIR"
mkdir -p /tmp/payg-vfs-dev

declare -a PIDS=()

cleanup() {
    echo ""
    echo "=========================================================="
    echo "🛑 Shutting down all Growatt PAYG Enterprise services..."
    echo "=========================================================="
    for pid in "${PIDS[@]}"; do
        if kill -0 "$pid" 2>/dev/null; then
            kill -TERM "$pid" 2>/dev/null || true
        fi
    done

    # Give processes a moment to exit gracefully
    sleep 1
    for pid in "${PIDS[@]}"; do
        if kill -0 "$pid" 2>/dev/null; then
            kill -9 "$pid" 2>/dev/null || true
        fi
    done

    echo "✅ All background services stopped cleanly."
    exit 0
}

trap cleanup SIGINT SIGTERM EXIT

echo "=========================================================="
echo "🚀 Booting Enterprise Growatt PAYG & Smart Energy Platform"
echo "=========================================================="

# Clean up any lingering processes on service ports before starting
fuser -k -9 8080/tcp 2>/dev/null || true
fuser -k -9 8000/tcp 2>/dev/null || true
lsof -ti:8080 | xargs -r kill -9 2>/dev/null || true
lsof -ti:8000 | xargs -r kill -9 2>/dev/null || true
pkill -9 -f "api-server" 2>/dev/null || true
pkill -9 -f "cmd/api-server" 2>/dev/null || true
pkill -9 -f "mqtt-gateway" 2>/dev/null || true
pkill -9 -f "cron-scheduler" 2>/dev/null || true
pkill -9 -f "app.main:app" 2>/dev/null || true
pkill -9 -f "uvicorn" 2>/dev/null || true
sleep 1

# 1. Docker Infrastructure (Postgres 16, EMQX 5, Redis 7)
if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
    echo "🐳 [1/4] Starting Docker cluster (Postgres, EMQX, Redis)..."
    (cd "$ROOT_DIR" && docker compose up -d) || echo "⚠️  Docker compose up failed, continuing with local services..."
else
    echo "ℹ️  [1/4] Docker daemon not active; proceeding with application microservices..."
fi

# 2. Python Intelligence Engine (FastAPI & ML Forecasting)
PY_DIR="$ROOT_DIR/intelligence-engine"
UVICORN_BIN=""
if [ -x "$PY_DIR/.venv/bin/uvicorn" ]; then
    UVICORN_BIN="$PY_DIR/.venv/bin/uvicorn"
elif [ -n "$VIRTUAL_ENV" ] && [ -x "$VIRTUAL_ENV/bin/uvicorn" ]; then
    UVICORN_BIN="$VIRTUAL_ENV/bin/uvicorn"
elif [ -x "$SCRIPT_DIR/.venv/bin/uvicorn" ]; then
    UVICORN_BIN="$SCRIPT_DIR/.venv/bin/uvicorn"
elif [ -x "$ROOT_DIR/.venv/bin/uvicorn" ]; then
    UVICORN_BIN="$ROOT_DIR/.venv/bin/uvicorn"
elif command -v uvicorn >/dev/null 2>&1; then
    UVICORN_BIN="$(command -v uvicorn)"
elif python3 -c "import uvicorn" >/dev/null 2>&1; then
    UVICORN_BIN="python3 -m uvicorn"
fi

if [ -z "$UVICORN_BIN" ]; then
    echo "⚙️  [2/4] First-time setup: Python virtual environment or uvicorn not found."
    echo "📦 Auto-provisioning .venv and installing required microservice dependencies..."
    if command -v python3 >/dev/null 2>&1; then
        (
            cd "$PY_DIR"
            if [ ! -d ".venv" ]; then
                python3 -m venv .venv
            fi
            .venv/bin/pip install --upgrade pip --quiet 2>/dev/null || true
            .venv/bin/pip install fastapi 'uvicorn[standard]' pydantic httpx numpy
        )
        if [ -x "$PY_DIR/.venv/bin/uvicorn" ]; then
            UVICORN_BIN="$PY_DIR/.venv/bin/uvicorn"
            echo "✅ Virtual environment auto-provisioned successfully!"
        fi
    else
        echo "❌ Error: python3 is not installed on this system. Please install python3 & python3-venv."
    fi
fi

echo "🧠 [2/4] Starting Python Intelligence Engine on http://localhost:8000..."
(
    cd "$ROOT_DIR/intelligence-engine"
    if [ -n "$UVICORN_BIN" ]; then
        export PYTHONPATH=.
        if [[ "$UVICORN_BIN" == python3* ]]; then
            exec python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8000
        else
            exec "$UVICORN_BIN" app.main:app --host 0.0.0.0 --port 8000
        fi
    else
        echo "❌ Error: uvicorn not found in .venv or system python3."
        echo "💡 Self-healing: cd $ROOT_DIR/intelligence-engine && python3 -m venv .venv && .venv/bin/pip install fastapi 'uvicorn[standard]' pydantic httpx numpy"
        exit 1
    fi
) > "$LOG_DIR/intelligence-engine.log" 2>&1 &
PIDS+=($!)

# 3. Core Go API Server
echo "⚡ [3/4] Starting Core Go API Server on http://localhost:8080..."
(
    cd "$ROOT_DIR/core-backend"
    if [ -x "bin/api-server" ]; then
        exec ./bin/api-server
    elif command -v go >/dev/null 2>&1; then
        exec go run ./cmd/api-server/main.go
    else
        echo "❌ Error: 'go' toolchain not installed and precompiled bin/api-server not found."
        echo "💡 Install Go (https://go.dev/doc/install) to run the Core API."
        exit 1
    fi
) > "$LOG_DIR/api-server.log" 2>&1 &
PIDS+=($!)

# 4. Background Workers (MQTT Gateway & Cron Scheduler)
echo "📡 [4/4] Starting Background Workers (MQTT Gateway & Cron Scheduler)..."
(
    cd "$ROOT_DIR/core-backend"
    if [ -x "bin/mqtt-gateway" ]; then
        exec ./bin/mqtt-gateway
    elif command -v go >/dev/null 2>&1; then
        exec go run ./cmd/mqtt-gateway/main.go
    else
        echo "❌ Error: Neither prebuilt bin/mqtt-gateway nor 'go' command found."
        exit 1
    fi
) > "$LOG_DIR/mqtt-gateway.log" 2>&1 &
PIDS+=($!)

(
    cd "$ROOT_DIR/core-backend"
    if [ -x "bin/cron-scheduler" ]; then
        exec ./bin/cron-scheduler
    elif command -v go >/dev/null 2>&1; then
        exec go run ./cmd/cron-scheduler/main.go
    else
        echo "❌ Error: Neither prebuilt bin/cron-scheduler nor 'go' command found."
        exit 1
    fi
) > "$LOG_DIR/cron-scheduler.log" 2>&1 &
PIDS+=($!)

echo ""
echo "⏳ Waiting for health check endpoints..."

# Health check polling
ALL_HEALTHY=false
for i in {1..20}; do
    CORE_HEALTH=$(curl -s http://localhost:8080/healthz || echo "")
    PY_HEALTH=$(curl -s http://localhost:8000/healthz || echo "")

    if [[ "$CORE_HEALTH" == *"healthy"* ]] && [[ "$PY_HEALTH" == *"healthy"* ]]; then
        ALL_HEALTHY=true
        break
    fi
    sleep 1
done

echo ""
if [ "$ALL_HEALTHY" = true ]; then
    echo "=========================================================="
    echo "🎉 ALL SERVICES ONLINE AND HEALTHY!"
    echo "=========================================================="
    echo "• Core REST API & Web UI:   http://localhost:8080"
    echo "  - Sizing & ROI Calculator: http://localhost:8080/api/v1/public/catalog"
    echo "  - Health Check:            http://localhost:8080/healthz"
    echo "• Intelligence Engine:      http://localhost:8000"
    echo "  - Interactive Swagger Docs: http://localhost:8000/docs"
    echo "  - Forecasting Health Check: http://localhost:8000/healthz"
    echo "• MQTT Gateway (EMQX):      tcp://localhost:1883"
    echo "• EMQX Admin Dashboard:     http://localhost:18083"
    echo "=========================================================="
else
    echo "=========================================================="
    echo "⚠️  WARNING: One or more services failed health checks!"
    echo "=========================================================="
    [[ "$CORE_HEALTH" == *"healthy"* ]] && echo "• Core REST API:            ONLINE (http://localhost:8080)" || echo "• Core REST API:            FAILED / OFFLINE (see $LOG_DIR/api-server.log)"
    [[ "$PY_HEALTH" == *"healthy"* ]] && echo "• Intelligence Engine:      ONLINE (http://localhost:8000)" || echo "• Intelligence Engine:      FAILED / OFFLINE (see $LOG_DIR/intelligence-engine.log)"
    echo "=========================================================="
fi
echo "📝 Streaming live server logs (Press Ctrl+C to stop all)..."
echo "=========================================================="
echo ""

# Stream logs with prefixes
tail -f "$LOG_DIR/api-server.log" "$LOG_DIR/intelligence-engine.log" &
TAIL_PID=$!
PIDS+=($TAIL_PID)

wait
